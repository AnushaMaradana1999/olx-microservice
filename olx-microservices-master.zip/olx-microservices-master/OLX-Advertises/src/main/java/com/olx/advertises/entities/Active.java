package com.olx.advertises.entities;

public enum Active {
	OPEN, CLOSED;
}
