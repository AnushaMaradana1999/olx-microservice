package com.olx.masterdata.service;

import java.util.List;

import com.olx.masterdata.entities.AdvStatus;

public interface AdvStatusService {
	
	public List<AdvStatus> allStatus();

}
