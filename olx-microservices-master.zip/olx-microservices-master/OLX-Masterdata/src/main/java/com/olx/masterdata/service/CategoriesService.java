package com.olx.masterdata.service;

import java.util.List;

import com.olx.masterdata.entities.Categories;

public interface CategoriesService {
	
	public List<Categories> allCategories();

}
